#ifndef __Ending_H__
#define __Ending_H__


#include "base.h"

#include "vector.h"


class Ending
{
public:
	Ending();
	~Ending();
	

	void Render();

private:
};


#endif 