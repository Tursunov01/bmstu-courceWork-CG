#pragma once

#include "Std.h"
#include "OGLCMainHeader.h"
#include "Engine.h"

extern HDC hDC;