

class Light
{

}